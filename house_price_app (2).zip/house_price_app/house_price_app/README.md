# HomeWorth — House Price Prediction (Python + ML + Web UI)

An end-to-end machine learning project: data generation, model comparison
(Ridge, Random Forest, Gradient Boosting), and a Flask web app with an
interactive UI that predicts a house price with a likely range.

## Project structure

```
house_price_app/
├── generate_data.py     # builds data/housing.csv (synthetic, realistic)
├── train.py             # trains 3 models, saves the best + metrics
├── app.py               # Flask server + /api/predict + /api/metrics
├── templates/index.html # the UI
├── requirements.txt
└── README.md
```

## Run it

```bash
pip install -r requirements.txt
python generate_data.py     # creates data/housing.csv
python train.py             # creates model/model.joblib + model/metrics.json
python app.py               # open http://127.0.0.1:5000
```

## Using a real dataset

Replace `data/housing.csv` with your own file and keep the same column names
(`city, locality, area_sqft, bhk, bathrooms, age_years, floor, total_floors,
parking, furnishing, lift, metro_km, price_lakh`), or edit `CATEGORICAL`,
`NUMERIC` and `TARGET` in `train.py`.

## How it works

1. **Preprocessing** — one-hot encoding for categorical columns, scaling for numeric ones, in a single scikit-learn `Pipeline`.
2. **Target** — trained on `log(1 + price)` so errors are relative across cheap and expensive cities.
3. **Model selection** — the model with the best R² on a held-out 20% test set is saved.
4. **Prediction range** — predicted price ± the model's MAPE on the test set.

## Ideas to extend

- Add SHAP explanations per prediction
- Hyper-parameter tuning with `GridSearchCV`
- Deploy on Render / Railway
- Add a map picker for locality
